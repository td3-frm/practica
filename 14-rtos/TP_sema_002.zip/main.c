/****************************************************************************
* 
*   This file contains MQX only stationery code.
*
****************************************************************************/
#include "main.h"
#include <mqx.h>
#include <bsp.h>
#include <fio.h>

#if !BSPCFG_ENABLE_IO_SUBSYSTEM
#error This application requires BSPCFG_ENABLE_IO_SUBSYSTEM defined non-zero in user_config.h. Please recompile BSP with this option.
#endif


#ifndef BSP_DEFAULT_IO_CHANNEL_DEFINED
#error This application requires BSP_DEFAULT_IO_CHANNEL to be not NULL. Please set corresponding BSPCFG_ENABLE_TTYx to non-zero in user_config.h and recompile BSP with this option.
#endif

//////////// ID TAREAS //////////////////////////////
// Task IDs  MAIN 
#define MAIN_TASK 	1

// Task IDs GIO 
#define GIO_TASK  	3	

// Task IDs  
#define TASK_INI	7
#define TAREA_PR    8
#define TAREA_CN    9


//////////// VARIABLES //////////////////////////////


// Structures holding information about specific pin 
LWGPIO_STRUCT led1, led2,led3,led4;


//--- productor-consumidor  
#define MAX_BUFFER 2           //tama�o del buffer
int cant;                      // numero de elementos en el buffer 
int buffer[MAX_BUFFER];        // buffer comun 
int DATOS_A_PRODUCIR=10;
int	valor_inicial;


//------ GIO
typedef enum {
    BUTTON_NOT_INITIALIZED = -1,
    BUTTON_RELEASED,
    BUTTON_PRESSED
} button_state_t;


//////////// TAREAS //////////////////////////////

extern void Main_task(uint32_t);

// ------- SEMAFOROS 
extern void task_ini(uint32_t );
extern void tarea_pr(uint32_t initial_data);
extern void tarea_cn(uint32_t initial_data);

//------ GIO 
void main_taskg(uint32_t);
void int_service_routine(void *);


//////////// TASK_TEMPLATE_STRUCT //////////////////////////////

const TASK_TEMPLATE_STRUCT  MQX_template_list[] = 
{
  // Task Index,   Function,   Stack,  Priority,   Name,   	Attributes,          Param, Time Slice 
    { MAIN_TASK,	Main_task,	 1500,  	2,	 	"main",   	MQX_AUTO_START_TASK,  0,     0 },
    { GIO_TASK,     main_taskg,  1500,   	3,      "maing", 	MQX_AUTO_START_TASK,  0,     0 },
    { TASK_INI, 	task_ini, 	 1000,  	4,   	"task_ini", MQX_AUTO_START_TASK,  0,     0 },
    { TAREA_PR, 	tarea_pr,  	 1000,  	6,   	"tar_pr", 	                  0,  0,     0 },
    { TAREA_CN,		tarea_cn, 	 1000,  	6,   	"tar_cn", 	                  0,  0,     0 },
   { 0 }
};


//-//-//-//-////-//-//-//-//- TAREAS //-//-//-//-////-//-//-//-////-//-//-//-////-//-//-//-////-//-//-//-//

/*--------- TASK -------------------------------------------
* 
* Task Name: Main_task
* Comments: Esta tarea imprime un leyenda
*
*-----------END TASK ---------------------------------------*/

void Main_task(uint32_t initial_data) {

	printf("\n Main, tarea de mayor prioridad, es la primera que va a ejecutarse\n"); 
   _task_block();

} //fin Main_task

/*--------- TASK -------------------------------------------
*
* Task Name: task_ini  
* Struct: (TASK_INI,task_ini,1000,5,"task_ini",MQX_AUTO_START_TASK,0,0 }, 
* Comments: 
* 	-Crea la tarea_pr --> productor
* 	-Crea la tarea_cn --> consumidor
* 	
*-----------END TASK ---------------------------------------*/

void task_ini (uint32_t initial_data)      {
  
  _task_id task_id1 , task_id2 ;	//ID de tareas
  
  char* strings1[] = { "Tarea_pr: Productor" };
  char* strings2[] = { "Tarea_cn: Consumidor" };
    
   // ------ crea tarea productor ------------------- 
   task_id1= _task_create(0, TAREA_PR, (uint32_t)strings1);  

   if (task_id1 == MQX_NULL_TASK_ID) {
      printf ("\n No se puede crear tarea_pr \n");
      _task_block();      
   } else {
      printf("\nCrea tarea_pr, ID=%d",task_id1 );
   }
   
   // ------ crea tarea consumidor ------------------- 
   task_id2 = _task_create(0, TAREA_CN, (uint32_t)strings2);  
   if (task_id2 == MQX_NULL_TASK_ID) {
      printf ("\n No se puede crear tarea_cn \n");
      _task_block();      
   } else {
      printf("\nCrea tarea_cn, ID=%d",task_id2 );  }
   
   _task_block();

} //fin task_ini   

/*--------- TASK -------------------------------------------
*
* Task Name: tarea_pr  
* Struct: {TAREA_PR,tarea_pr,1000,5,"tar_pr",0,0,0} 
* Comments: 
* 	La Tarea productor escribe datos en el Buffer
* 	
*-----------END TASK ---------------------------------------*/

//-------------- PRODUCTOR ---------------------------------

void tarea_pr (uint32_t initial_data)      {
  
	char **strings = (char **)initial_data;
	int i, pos=0;
	int dato=1000;
	
	_io_puts("\n"); 
	_io_puts(strings[0]); 
	
	// LWGPIO_VALUE_HIGH =1, LWGPIO_VALUE_LOW=0
	lwgpio_set_value(&led2, LWGPIO_VALUE_LOW);
	
//----------------------------------------
    
    for(i=0; i < DATOS_A_PRODUCIR; i++ ) {

		dato++;
		buffer[pos] = dato;      
		pos = (pos + 1);
		
		if (pos >= MAX_BUFFER) {
		pos=0;   

		}
		
		printf("\nProductor dato nro: %d, posicion buffer: %d, dato:%d",i,pos, dato); 

				
    } // fin for
    
    printf("\nTermina Productor: %d",i);

//----------------------------------------
    
    
    // LWGPIO_VALUE_HIGH =1, LWGPIO_VALUE_LOW=0
    lwgpio_set_value(&led2, LWGPIO_VALUE_HIGH);

    // LWGPIO_VALUE_HIGH =1, LWGPIO_VALUE_LOW=0
    lwgpio_set_value(&led1, LWGPIO_VALUE_LOW); 

    printf("\n Tarea_pr termina ");

	_task_block();   }


/*--------- TASK -------------------------------------------
*
* Task Name: tarea_cn  
* Struct: {TAREA_CN,tarea_cn,1000,5,"tar_cn",0,0,0} 
* Comments: 
* 	La Tarea consumidor lee datos del Buffer
* 	
*-----------END TASK ---------------------------------------*/

//-------------- CONSUMIDOR ---------------------------------

void tarea_cn (uint32_t initial_data)      {
  
	char **strings = (char **)initial_data;
	int dato, i, pos=0;

	_io_puts("\n"); 
	_io_puts(strings[0]); 

	// LWGPIO_VALUE_HIGH =1, LWGPIO_VALUE_LOW=0
	lwgpio_set_value(&led3, LWGPIO_VALUE_LOW); 

//----------------------------------------	   

	for(i=0; i < DATOS_A_PRODUCIR; i++ ) {

		dato = buffer[pos];
		pos = (pos + 1) ;
		
		if (pos>= MAX_BUFFER) {
		pos=0;   

		}
		
		printf("\nConsumidor dato nro: %d, posicion buffer: %d, dato:%d",i,pos, dato);
		
 } // fin for
  
//----------------------------------------	
	
   printf("\nTermina Consumidor: %d",i);	
	
	// LWGPIO_VALUE_HIGH =1, LWGPIO_VALUE_LOW=0
	lwgpio_set_value(&led3, LWGPIO_VALUE_HIGH); 
	
    // LWGPIO_VALUE_HIGH =1, LWGPIO_VALUE_LOW=0
    lwgpio_set_value(&led4, LWGPIO_VALUE_LOW); 

	printf("\n Tarea_cn termina ");

    _task_block();   }


////////////////////////////// GIO ////////////////////////////////////////////

/******************************************************************************
*
* Functio Name      : int_service_routine
* Comments          : The interrupt service routine triggered by gpio
*
******************************************************************************/
void int_service_routine(void *pin) {

	lwgpio_int_clear_flag((LWGPIO_STRUCT_PTR) pin);
}

/******************************************************************************
*
* Task Name    : main_taskg
* Comments     : The main task executes 3 steps
*
*   1) Configures BSP_BUTTON1 to trigger interrupt on falling edge if supported
*      by selected platform.
*   2) Drives BSP_LED1 based on BSP_BUTTON1 state or
*      drives BSP_LED1 automatically if BSP_BUTTON1 is not available.
*   3) Togles BSP_LED1 if BSP_BUTTON1 is not available
*
******************************************************************************/
void main_taskg (uint32_t initial_data ) {

//////////////////////////// LEDS ///////////////////////////////////////////////
    
#ifdef BSP_LED1
/******************************************************************************
    Open the BSP_LED1) pin as output and drive the output level high.
******************************************************************************/
    /* initialize lwgpio handle (led1) for BSP_LED1 pin
     * (defined in mqx/source/bsp/<bsp_name>/<bsp_name>.h file)
     */
    if (!lwgpio_init(&led1, BSP_LED1, LWGPIO_DIR_OUTPUT, LWGPIO_VALUE_NOCHANGE)) {
        printf("Inicializacion de LED1 GPIO falla.\n");
        _task_block();     }
    
    /* swich pin functionality (MUX) to GPIO mode */
    lwgpio_set_functionality(&led1, BSP_LED1_MUX_GPIO);

    // LWGPIO_VALUE_HIGH =1, LWGPIO_VALUE_LOW=0
    lwgpio_set_value(&led1, LWGPIO_VALUE_HIGH); //set pin to 1 
    
#endif //BSP_LED1

#ifdef BSP_LED2
/******************************************************************************
    Open the BSP_LED2) pin as output and drive the output level high.
******************************************************************************/
    /* initialize lwgpio handle (led2) for BSP_LED2 pin
     * (defined in mqx/source/bsp/<bsp_name>/<bsp_name>.h file)
     */
    if (!lwgpio_init(&led2, BSP_LED2, LWGPIO_DIR_OUTPUT, LWGPIO_VALUE_NOCHANGE)) {
        printf("Inicializacion de LED2 GPIO falla.\n");
        _task_block();     }

    /* swich pin functionality (MUX) to GPIO mode */
    lwgpio_set_functionality(&led2, BSP_LED2_MUX_GPIO);

    // LWGPIO_VALUE_HIGH =1, LWGPIO_VALUE_LOW=0
    lwgpio_set_value(&led2, LWGPIO_VALUE_HIGH); // set pin to 0 

    #endif //BSP_LED2

#ifdef BSP_LED3
/******************************************************************************
    Open the BSP_LED3) pin as output and drive the output level high.
******************************************************************************/
    /* initialize lwgpio handle (led3) for BSP_LED3 pin
     * (defined in mqx/source/bsp/<bsp_name>/<bsp_name>.h file)
     */
    if (!lwgpio_init(&led3, BSP_LED3, LWGPIO_DIR_OUTPUT, LWGPIO_VALUE_NOCHANGE))  {
        printf("Inicializacion de LED3 GPIO falla.\n");
        _task_block();    }
    
    /* swich pin functionality (MUX) to GPIO mode */
    lwgpio_set_functionality(&led3, BSP_LED3_MUX_GPIO);

    // LWGPIO_VALUE_HIGH =1, LWGPIO_VALUE_LOW=0
    lwgpio_set_value(&led3, LWGPIO_VALUE_HIGH); /* set pin to 1 */

    #endif //BSP_LED3

#ifdef BSP_LED4
/******************************************************************************
    Open the BSP_LED4) pin as output and drive the output level high.
******************************************************************************/
    /* initialize lwgpio handle (led4) for BSP_LED4 pin
     * (defined in mqx/source/bsp/<bsp_name>/<bsp_name>.h file)
     */
    if (!lwgpio_init(&led4, BSP_LED4, LWGPIO_DIR_OUTPUT, LWGPIO_VALUE_NOCHANGE))    {
        printf("Inicializacion de LED4 GPIO falla.\n");
        _task_block();    }

    /* swich pin functionality (MUX) to GPIO mode */
    lwgpio_set_functionality(&led4, BSP_LED4_MUX_GPIO);

    // LWGPIO_VALUE_HIGH =1, LWGPIO_VALUE_LOW=0
    lwgpio_set_value(&led4, LWGPIO_VALUE_HIGH); /* set pin to 0 */

    #endif //BSP_LED4

}

/* EOF */
