// EJERCICIO DE TP RTOS 
// CREACION DE TAREAS
//
/****************************************************************************
* 
*   This file contains MQX only stationery code.
*
****************************************************************************/
#include "main.h"
#include <mqx.h>
#include <bsp.h>


#if !BSPCFG_ENABLE_IO_SUBSYSTEM
#error This application requires BSPCFG_ENABLE_IO_SUBSYSTEM defined non-zero in user_config.h. Please recompile BSP with this option.
#endif


#ifndef BSP_DEFAULT_IO_CHANNEL_DEFINED
#error This application requires BSP_DEFAULT_IO_CHANNEL to be not NULL. Please set corresponding BSPCFG_ENABLE_TTYx to non-zero in user_config.h and recompile BSP with this option.
#endif


//////////// ID TAREAS //////////////////////////////
// Task IDs  MAIN 
#define MAIN_TASK 	1
#define TAREA1 		2
#define TAREA2 		3

//////////// TAREAS //////////////////////////////
extern void Main_task(uint32_t);
extern void tarea_1(uint32_t initial_data);
extern void tarea_2(uint32_t initial_data);


//////////// TASK_TEMPLATE_STRUCT //////////////////////////////

const TASK_TEMPLATE_STRUCT  MQX_template_list[] = 
{
  // Task Index,   Function,   Stack,  Priority,   Name,   	       Attributes,     Param, Time Slice 
    { MAIN_TASK,	Main_task,	 1500,  	6,	 	"main",   	MQX_AUTO_START_TASK,  0,     0 },
    {    TAREA1,      tarea_1, 	 1500,  	7,    "tarea1", 	                  0,  0,     0 },
    {    TAREA2, 	  tarea_2, 	 1500,  	7,    "tarea2", 	                  0,  0,     0 },
    {         0,            0,      0,      0,           0,                       0,  0,     0 },
};


//-//-//-//-////-//-//-//-//- TAREAS //-//-//-//-//-//-//-//-//-//-//-//-//-//-//-//-//-//-//-////-//-//-//-//



/*TASK*-----------------------------------------------------
* 
* Task Name    : Main_task
* Comments     :
*    Esta tarea imprime " Hola Mundo! "
*    Crea dos tareas: tarea_1, tarea_2
*
*END*-----------------------------------------------------*/

void Main_task(uint32_t initial_data)
{
	_task_id task_id1 , task_id2 ;	//ID de tareas
	
	char* strings1[] = { "dato para tarea_1 " };
	char* strings2[] = { "dato para tarea_2 " };
		
	printf("\n Hola Mundo! \n"); 

	// ------ crea tarea 1 ------------------- 
	task_id1= _task_create(0, TAREA1, (uint32_t)strings1);  
	
	if (task_id1 == MQX_NULL_TASK_ID) {
	  printf ("\n No se puede crear tarea_1 \n");
	  _task_block();      
	} else {
	  printf("\nCrea tarea_1, ID=%d",task_id1 );
	}
	
	// ------ crea tarea 2 ------------------- 
	task_id2 = _task_create(0, TAREA2, (uint32_t)strings2);  
	if (task_id2 == MQX_NULL_TASK_ID) {
	  printf ("\n No se puede crear tarea_2 \n");
	  _task_block();      
	} else {
	  printf("\nCrea tarea_2, ID=%d",task_id2 );  }

	//_task_destroy( task_id2);	
	_task_block();   
   //_mqx_exit(0);
}

/*--------- TAREA 1 -------------------------------------------
*
* Task Name: tarea_1  
* Struct: {TAREA1,tarea_1,1500,7,"tarea1",0,0,0} 
* Comments: 
* 	La Tarea muestra el dato 
* 	
*-----------END TASK ---------------------------------------*/

void tarea_1 (uint32_t initial_data)      {
  
	char **strings = (char **)initial_data;

	printf("\nComienza Tarea_1 ");
	
	_io_puts("\n"); 
	_io_puts(strings[0]); 

	printf("\nTarea_1 termina ");

	_task_block();   
    //_mqx_exit(0);
}


/*--------- TAREA 2 -------------------------------------------
*
* Task Name: tarea_2  
* Struct: {TAREA2,tarea_2,1500,7,"tarea1",0,0,0} 
* Comments: 
* 	La Tarea muestra el dato 
* 	
*-----------END TASK ---------------------------------------*/

void tarea_2 (uint32_t initial_data)      {
  
	char **strings = (char **)initial_data;

	printf("\nComienza Tarea_2 ");
	
	_io_puts("\n"); 
	_io_puts(strings[0]); 

	printf("\nTarea_2 termina ");

	_task_block();   
}



/* EOF */
