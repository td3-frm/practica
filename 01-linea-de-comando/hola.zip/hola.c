#include <stdio.h>
#include <stdlib.h>

int main(void)
{
 printf("Hola Mundo!\n");
 
 // while(1);
 
 exit(0);

}	
