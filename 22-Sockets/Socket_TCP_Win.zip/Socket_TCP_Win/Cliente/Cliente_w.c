
///////////////////////////////////////////////////
//Para linkear la biblioteca winsock2:
//1) Ir a proyecto / opciones de proyecto 
//2) Pesta�a Par�metros y ventana Linker 
//3) presionar boton A�adir Biblioteca u objeto
//4) buscar en ruta c:\Dev-Cpp\lib buscar      libws2_32.a
///////////////////////////////////////////////////

#include <windows.h>
#include <winsock2.h>
#pragma comment(lib,"libws2_32.a")
#include <time.h>
#include <stdio.h>
#include <windows.h>
#include <winsock.h>
 

char buff_tcl[256], buff_sck[56];
int lee_tcl, lee_sck;
 
int main(int argc, char *argv[]) {
    
  WSADATA WsaData;
  WORD  wVersionRequerida = MAKEWORD (2, 2);
 
  //-- Inicializar WinSock ----------------//
  WSAStartup (wVersionRequerida, &WsaData);
 
  SOCKET sockfd;
 
  //****************** 1 *******************//
 //-- socket(): Crear el socket -----------//

  sockfd = socket (AF_INET, SOCK_STREAM, 0);

  printf ("Paso 1: Se creo socket cliente: %d\n",  sockfd);
 
 //****************** 2 *******************//

//-- preparar el address:port del host servidor------//

  SOCKADDR_IN DireccionServer;
  memset (&DireccionServer, 0, sizeof (DireccionServer));
  DireccionServer.sin_family = AF_INET;
  DireccionServer.sin_addr.S_un.S_un_b.s_b1 = 127;
  DireccionServer.sin_addr.S_un.S_un_b.s_b2 = 0;
  DireccionServer.sin_addr.S_un.S_un_b.s_b3 = 0;
  DireccionServer.sin_addr.S_un.S_un_b.s_b4 = 1;
  DireccionServer.sin_port = 5000;
 
  printf ("Cliente va a conectarse con IP:127.0.0.1 Puerto: 5000\n");

//-- conectar el socket activo al socket de escucha --//

  int iResult = connect (sockfd, (SOCKADDR*) &DireccionServer,sizeof(DireccionServer));
 
  if (iResult)   {
    printf ("No se puede conectar\n");
    return 0;  }

  printf ("Paso 2: Connect(), cliente conectado\n");
 
//****************** 3 *******************//

  while(1){ 
   
     lee_sck = recv ( sockfd , buff_sck, sizeof (buff_tcl),0);    //lee de socket 
     write (STDOUT_FILENO, "Servidor:--> ", 13);               //escribe leyenda en pantalla
     write (STDOUT_FILENO, buff_sck, lee_sck);                  //escribe lo leido del socket

     if (( lee_tcl = read(STDIN_FILENO, buff_tcl, sizeof (buff_tcl))) > 0) {     // lee de teclado
        send (sockfd ,buff_tcl, lee_tcl,0 );                   //escribe en socket

    }
 
 }// while(1)
 
  closesocket (sockfd);
 
  return 0;
}

