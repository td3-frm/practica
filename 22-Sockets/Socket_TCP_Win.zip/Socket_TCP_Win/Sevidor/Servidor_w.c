///////////////////////////////////////////////////
//Para linkear la biblioteca winsock2:
//1) Ir a proyecto / opciones de proyecto 
//2) Pesta�a Par�metros y ventana Linker 
//3) presionar boton A�adir Biblioteca u objeto
//4) buscar en ruta c:\Dev-Cpp\lib buscar      libws2_32.a
///////////////////////////////////////////////////

#include <windows.h>
#include <winsock2.h>
#pragma comment(lib,"libws2_32.a")

#include <time.h>
#include <stdio.h>
#include <windows.h>
#include <winsock.h>

char buffer_rx[256];
int  rx_socket, cont;
    
int main(int argc, char *argv[]) {

  //-- Inicializar WinSock ----------------//
  WSADATA WsaData;
  WORD  wVersionRequerida = MAKEWORD (2, 2);
  WSAStartup (wVersionRequerida, &WsaData);
 
  SOCKET SockEscucha;
 
  //****************** 1 *******************//
 //-- socket(): Crear el socket -----------//
  SockEscucha = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP);

   printf ("Paso 1: Servidor creo socket: %d\n",  SockEscucha);

 //****************** 2 *******************//

//-- preparar el address:port -------------//
  SOCKADDR_IN DireccionLocal;
  DireccionLocal.sin_family = AF_INET;
  DireccionLocal.sin_port = 5000;                // puerto
  DireccionLocal.sin_addr.s_addr = INADDR_ANY;  // asigna una IP de la maquina


//-- bind(): asociamos el socket al puerto ------//
   if (bind(SockEscucha, (SOCKADDR*) &DireccionLocal, sizeof(DireccionLocal))==-1)   {
      printf("error en el bind\n");
      return -1;   }

    printf ("Paso 2: Asociar bind() \n");

 
 //****************** 3 *******************//
 //-- listen(): Permitir hasta 1 conexiones pendientes --//
 //ponemos el socket a la escucha
 
   int iResult = listen (SockEscucha, 5);
   if (iResult==-1)   {
      printf("error en el listen\n");
      return -1;   }

   printf ("Paso 3: Permitir conexiones listen()\n");

  while(1) {

 //****************** 4 *******************//
   printf ("Paso 4: Bloqueo hasta que entre conexion accept()\n");
   cont=0;     

 //-- accept(): se bloquea hasta que entre una conexion --//
  SOCKET SockConexion = accept (SockEscucha, NULL, NULL);

   if (SockConexion >=0) {  
      if (cont==0) {
           printf ("Desbloqueo de accept, entro conexion: %d\n",SockConexion);
           send (SockConexion ,"Bienvenido al servidor\n", 23,0 ); 
      cont=1;  }   

      while (( rx_socket = recv(SockConexion, buffer_rx, sizeof (buffer_rx),0)) > 0) {  //lee del socket    
              send (SockConexion ,buffer_rx, rx_socket,0 ); 
              write ( STDOUT_FILENO , "cliente:--> ", 12);         //escribe leyenda en pantalla
              write ( STDOUT_FILENO , buffer_rx, rx_socket);      //escribe lo leido del socket
       }
    } else { printf ("Error en la conexion\n");  }

    
} //while(1)    

  return 0;

} // main
