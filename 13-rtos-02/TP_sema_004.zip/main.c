/*HEADER**********************************************************************
*
* Copyright 2008 Freescale Semiconductor, Inc.
* Copyright 1989-2008 ARC International
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale MQX RTOS License distributed with this Material.
* See the MQX_RTOS_LICENSE file distributed for more details.
*
* Brief License Summary:
* This software is provided in source form for you to use free of charge, but it is not open source software. 
* You are allowed to use this software but you cannot redistribute it or derivative works of it in source form.
* The software may be used only in connection with a product containing a Freescale microprocessor, microcontroller, 
* or digital signal processor. See license agreement file for full license terms including other restrictions.
*****************************************************************************
*END************************************************************************/


// include //
#include <mqx.h>
#include <bsp.h>
#include <fio.h>


#if ! BSPCFG_ENABLE_IO_SUBSYSTEM
#error This application requires BSPCFG_ENABLE_IO_SUBSYSTEM defined non-zero in user_config.h. Please recompile BSP with this option.
#endif


#ifndef BSP_DEFAULT_IO_CHANNEL_DEFINED
#error This application requires BSP_DEFAULT_IO_CHANNEL to be not NULL. Please set corresponding BSPCFG_ENABLE_TTYx to non-zero in user_config.h and recompile BSP with this option.
#endif


//----ID TAREAS---------------------------------------------------------------------------------------------

/* Task IDs GIO */
#define GIO_TASK  		5	//GIO
#define MAIN_TASK     	6
#define PRINT_TASK    	7

//----DECLARACION DE FUNCIONES--------------------------------------------------------------------------------

//------ GIO --------------------
/* Function prototypes */
void gio_task(uint32_t);
void int_service_routine(void *);
void main_task(uint32_t initial_data);
void print_task(uint32_t initial_data);


//------------------------------------------------------------------------------------------------------------

//------ GIO --------------------
typedef enum {
    BUTTON_NOT_INITIALIZED = -1,
    BUTTON_RELEASED,
    BUTTON_PRESSED
} button_state_t;


//----DECLARACION DE TAREAS-----------------------------------------------------------------------------------

const TASK_TEMPLATE_STRUCT  MQX_template_list[] = 
{
   /* Task Index,   Function,   Stack,  Priority,   Name,   Attributes,          Param, Time Slice */
    { GIO_TASK,     gio_task, 1500,     4,          "maing", MQX_AUTO_START_TASK,  0,     0 },
    { MAIN_TASK,    main_task,  1000,   5,          "main",  MQX_AUTO_START_TASK,  0,     0 },
    { PRINT_TASK,   print_task, 1000,   6,          "print", 0,                    0,     3 },
    { 0 }
};

/* Structures holding information about specific pin */
LWGPIO_STRUCT btn1,led1, led2,led3,led4;



//--- GIO ---------------
LWSEM_STRUCT lwsem;
int contador;

//----TAREAS--------------------------------------------------------------------------------------------------

/*TASK*--------------------------------------------------------
*
* Task Name : main_task   //MAIN_TASK,main_task,1000,5,"main",MQX_AUTO_START_TASK,0,0 
* Prioridad : 5
* Comments  : This task creates a mutex and then two instances of the print task.
* 
*END*--------------------------------------------------------*/

void main_task(uint32_t initial_data) {
	
   char*            strings1[] = { "cadena1" };
   char*            strings2[] = { "cadena2" };

   contador=2;		//inicializo contador en 2 para que no se quede eternamente en el bucle
   
   /* Create the print tasks */ //CREA LAS TRAREAS PRINT CON LOS STRING 1 Y 2
   _task_create(0, PRINT_TASK, (uint32_t)strings1); //"1: ", "cadena 1\n" 
   _task_create(0, PRINT_TASK, (uint32_t)strings2); //"2: ", "cadena 2\n" 

   _task_block();
}   

/*TASK*--------------------------------------------------------
*
* Task Name : print_task     //PRINT_TASK,print_task,1000,6,"print", 0,0,3 
* Prioridad : 6
* Comments  : This task prints a message. It uses a mutex to ensure I/O is not interleaved.
*         lwgpio_toggle_value(&led1);
        _time_delay(250);
* 
*END*--------------------------------------------------------*/

void print_task(uint32_t initial_data) {
	
   char **strings = (char **)initial_data;

     if (strings[0]=="cadena1"){
    	 printf ("recibido: ,%s\n",strings[0]);
    	 lwgpio_toggle_value(&led3);
         _time_delay(500);
     }

      if (strings[0]=="cadena2"){
     	 printf ("recibido: ,%s\n",strings[0]);
          lwgpio_toggle_value(&led4);
          _time_delay(500);
      }

   _task_block(); ////////////////
}


////////////////////////////// GIO ////////////////////////////////////////////

/******************************************************************************
*
* Functio Name      : int_service_routine
* Comments          : The interrupt service routine triggered by gpio
*
******************************************************************************/
void int_service_routine(void *pin)
{
    lwgpio_int_clear_flag((LWGPIO_STRUCT_PTR) pin);
    _lwsem_post(&lwsem);	//incrementa el semaforo
}

/******************************************************************************
*
* Task Name    : gio_task
* Comments     : The main task executes 3 steps
*
*   1) Configures BSP_BUTTON1 to trigger interrupt on falling edge if supported
*      by selected platform.
*   2) Drives BSP_LED1 based on BSP_BUTTON1 state or
*      drives BSP_LED1 automatically if BSP_BUTTON1 is not available.
*   3) Togles BSP_LED1 if BSP_BUTTON1 is not available
*
******************************************************************************/
void gio_task (uint32_t initial_data) {
	
    /* Structures holding information about specific pin */
    //LWGPIO_STRUCT btn1,led1, led2,led3,led4;
    button_state_t  button_state, button_last_state;
    int button_press_count;
    _mqx_uint result;

    /* Create the lightweight semaphore */
    result = _lwsem_create(&lwsem, 0);
    if (result != MQX_OK) {
        printf("\nCreating sem failed: 0x%X", result);
        _task_block();
    } else {  // tuvo exito al crear la tarea
       printf("se crea sem�foro, inicializado en cero\n ");
    }
    
     
#ifdef BSP_LED1
/******************************************************************************
    Open the BSP_LED1) pin as output and drive the output level high.
******************************************************************************/
    /* initialize lwgpio handle (led1) for BSP_LED1 pin
     * (defined in mqx/source/bsp/<bsp_name>/<bsp_name>.h file)
     */
    if (!lwgpio_init(&led1, BSP_LED1, LWGPIO_DIR_OUTPUT, LWGPIO_VALUE_NOCHANGE))
    {
        printf("Initializing LED1 GPIO as output failed.\n");
        _task_block();
    }
    /* swich pin functionality (MUX) to GPIO mode */
    lwgpio_set_functionality(&led1, BSP_LED1_MUX_GPIO);

    /* write logical 1 to the pin */
    lwgpio_set_value(&led1, LWGPIO_VALUE_LOW); /* set pin to 1 */

    #endif //BSP_LED1

#ifdef BSP_LED2
/******************************************************************************
    Open the BSP_LED2) pin as output and drive the output level high.
******************************************************************************/
    /* initialize lwgpio handle (led2) for BSP_LED2 pin
     * (defined in mqx/source/bsp/<bsp_name>/<bsp_name>.h file)
     */
    if (!lwgpio_init(&led2, BSP_LED2, LWGPIO_DIR_OUTPUT, LWGPIO_VALUE_NOCHANGE))
    {
        printf("Initializing LED2 GPIO as output failed.\n");
        _task_block();
    }
    /* swich pin functionality (MUX) to GPIO mode */
    lwgpio_set_functionality(&led2, BSP_LED2_MUX_GPIO);

    /* write logical 1 to the pin */
    lwgpio_set_value(&led2, LWGPIO_VALUE_LOW); /* set pin to 1 */ 
#endif //BSP_LED2

#ifdef BSP_LED3
/******************************************************************************
    Open the BSP_LED3) pin as output and drive the output level high.
******************************************************************************/
    /* initialize lwgpio handle (led3) for BSP_LED3 pin
     * (defined in mqx/source/bsp/<bsp_name>/<bsp_name>.h file)
     */
    if (!lwgpio_init(&led3, BSP_LED3, LWGPIO_DIR_OUTPUT, LWGPIO_VALUE_NOCHANGE))
    {
        printf("Initializing LED3 GPIO as output failed.\n");
        _task_block();
    }
    /* swich pin functionality (MUX) to GPIO mode */
    lwgpio_set_functionality(&led3, BSP_LED3_MUX_GPIO);

    /* write logical 1 to the pin */
    lwgpio_set_value(&led3, LWGPIO_VALUE_LOW); /* set pin to 1 */
#endif //BSP_LED3

#ifdef BSP_LED4
/******************************************************************************
    Open the BSP_LED4) pin as output and drive the output level high.
******************************************************************************/
    /* initialize lwgpio handle (led4) for BSP_LED4 pin
     * (defined in mqx/source/bsp/<bsp_name>/<bsp_name>.h file)
     */
    if (!lwgpio_init(&led4, BSP_LED4, LWGPIO_DIR_OUTPUT, LWGPIO_VALUE_NOCHANGE))
    {
        printf("Initializing LED4 GPIO as output failed.\n");
        _task_block();
    }
    /* swich pin functionality (MUX) to GPIO mode */
    lwgpio_set_functionality(&led4, BSP_LED4_MUX_GPIO);

    /* write logical 1 to the pin */
    lwgpio_set_value(&led4, LWGPIO_VALUE_LOW); /* set pin to 1 */
#endif //BSP_LED4
    
#if defined BSP_BUTTON1
/******************************************************************************
    Open the pin (BSP_BTN1) for input, initialize interrupt
    and set interrupt handler.
******************************************************************************/
    /* opening pins for input */
    if (!lwgpio_init(&btn1, BSP_BUTTON1, LWGPIO_DIR_INPUT, LWGPIO_VALUE_NOCHANGE))
    {
        printf("Initializing button GPIO as input failed.\n");
        _task_block();
    }

#ifdef BSP_BUTTON1_MUX_IRQ
    /* Some platforms require to setup MUX to IRQ functionality,
    for the rest just set MUXto GPIO functionality */
    lwgpio_set_functionality(&btn1, BSP_BUTTON1_MUX_IRQ);
#if defined(BSP_BUTTONS_ACTIVE_HIGH)
    lwgpio_set_attribute(&btn1, LWGPIO_ATTR_PULL_DOWN, LWGPIO_AVAL_ENABLE);
#else
    lwgpio_set_attribute(&btn1, LWGPIO_ATTR_PULL_UP, LWGPIO_AVAL_ENABLE);
#endif  //defined(BSP_BUTTONS_ACTIVE_HIGH)

    /* enable gpio functionality for given pin, react on falling edge */
    if (!lwgpio_int_init(&btn1, LWGPIO_INT_MODE_FALLING))
    {
        printf("Initializing button GPIO for interrupt failed.\n");
        _task_block();
    }

    /* install gpio interrupt service routine */
    _int_install_isr(lwgpio_int_get_vector(&btn1), int_service_routine, (void *) &btn1);
    /* set the interrupt level, and unmask the interrupt in interrupt controller */
    _bsp_int_init(lwgpio_int_get_vector(&btn1), 3, 0, TRUE);
 
    /* enable interrupt on GPIO peripheral module */
    lwgpio_int_enable(&btn1, TRUE);

    printf("\n====================== GPIO Example ======================\n");
    printf("The (SW1) button is configured to trigger GPIO interrupt.\n");
    printf("Press the (SW1) button 3x to continue.\n\n");
    button_press_count = 1;

    while(button_press_count < 3)       {
        /* wait for button press, lwsem is set in button isr */
        _lwsem_wait(&lwsem);
        printf("Button pressed %dx\r", button_press_count++);
    }
    /* disable interrupt on GPIO peripheral module */
    lwgpio_int_enable(&btn1, FALSE);

    printf("\n desahbilita interrupci�n GIO \n");
#endif /* BSP_BUTTON1_MUX_IRQ */

/******************************************************************************
    Read value from input pin (BSP_BTN1)  Note that in previous phase,
    the pin was configured as an interrupt and it have to be reconfigured
    to standard GPIO.
******************************************************************************/
    /* set pin functionality (MUX) to GPIO*/
    lwgpio_set_functionality(&btn1, BSP_BUTTON1_MUX_GPIO);
#if defined(BSP_BUTTONS_ACTIVE_HIGH)
    lwgpio_set_attribute(&btn1, LWGPIO_ATTR_PULL_DOWN, LWGPIO_AVAL_ENABLE);
#else
    lwgpio_set_attribute(&btn1, LWGPIO_ATTR_PULL_UP, LWGPIO_AVAL_ENABLE);
#endif

    printf("The (SW1) button state is now polled.\n");
    printf("Press the (SW1) button to switch LED on or off\n\n");

    button_last_state = BUTTON_NOT_INITIALIZED;

    while (TRUE)
    {
         /* read pin/signal status */
#if defined(BSP_BUTTONS_ACTIVE_HIGH)
        if (LWGPIO_VALUE_HIGH == lwgpio_get_value(&btn1))
#else
        if (LWGPIO_VALUE_LOW == lwgpio_get_value(&btn1))
#endif
        {
            button_state = BUTTON_PRESSED;
        }
        else
        {
            button_state = BUTTON_RELEASED;
        }

        if (button_state != button_last_state)  {
            printf("Button %s\r", button_state == BUTTON_PRESSED ? "pressed " : "released");
            button_last_state = button_state;
#ifdef BSP_LED1
            lwgpio_set_value(&led1, button_state == BUTTON_PRESSED ? LWGPIO_VALUE_LOW : LWGPIO_VALUE_HIGH);
#endif /* BSP_LED1 */

#ifdef BSP_LED2
            lwgpio_set_value(&led2, button_state == BUTTON_PRESSED ? LWGPIO_VALUE_HIGH : LWGPIO_VALUE_LOW);
#endif /* BSP_LED2 */

        }
  }
#endif /* BSP_LED1, BSP_BUTTON1 */ //BSP_BUTTON1
}

/* EOF */
