/*  
 * Ejercicio 1 de la guía práctica Memoria compartida
 * Tipica implementacion de una memoria compartida
 */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/shm.h>

#define MEM_COM "MEM_COMP"
#define MENSAJE "INFORMACION PARA OTRO PROCESO\n"

int main()
{	
	int fd, leido, largo ;
	int *ptr;
	char buff[1024];
	struct stat sb;
	
	// Se crea el descriptor de la memoria compartida
   fd = shm_open(MEM_COM , O_RDWR|O_CREAT, 0777 );
	if (fd == -1){
          fprintf(stderr, "ERROR EN OPEN\n");
          return 255;
        }
	
	// Se dimensiona la memoria y se pone a cero
	largo = 1024;	
	int ft = ftruncate(fd, largo);
	if (ft == -1){
          fprintf(stderr, "ERROR EN FTRUNCATE\n");
          return 255;
    }
	
	// Se mapea la memoria compartida al espacio de memoria del proceso
	ptr = mmap(NULL, 10, PROT_READ |PROT_WRITE, MAP_SHARED, fd, 0 );
	if (ptr == (void *)-1){
          fprintf(stderr, "ERROR EN MMAP\n");
          return 255;
    }
    printf ("Direccion de memoria local donde arranca la memoria %p\n", ptr);	
    
    // Hacer >$ls /dev/shm
    
    // Se copia información en la memoria
    memcpy(ptr, MENSAJE, sizeof(MENSAJE));
    
    // Hacer >$cat /dev/shm/MEM_COM 
    
    // Se lee el estado de la memoria y se guarda en la estructura sb
   	if (fstat(fd, &sb) == -1)
	   	exit(-1);
	    	
 	// Se lee de la memoria compartida y se imprime por pantalla
	write(STDOUT_FILENO, ptr, sb.st_size);
    
    // Borrar memoria compartida   
	//~ if (shm_unlink(MEM_COM) == -1)
	//~ {
		//~ fprintf(stderr, "ERROR EN shm_unlink\n");
		//~ exit(-1);}
		        
	return 0;
}
