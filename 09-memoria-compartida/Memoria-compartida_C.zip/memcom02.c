/*  
 * Ejercicio 2 de la guía práctica Memoria compartida
 * 
 */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/shm.h>

#define MEM_COM "MEM_COMPARTIDA"
#define MENSAJE "INFORMACION PARA OTRO PROCESO\n"

int main()
{	
	int fd, leido, largo ;
	int *ptr;
	char buff[1024];
	struct stat sb;
	
	// Se crea el objeto de memoria compartida
   fd = shm_open(MEM_COM , O_RDONLY|O_CREAT, 0777 );
	if (fd == -1){
          fprintf(stderr, "ERROR EN OPEN\n");
          return 255;
        }
	
	//~ // Se dimensiona la memoria y se pone a cero
	//~ largo = 1024;	
	//~ int ft = ftruncate(fd, largo);
	//~ if (ft == -1){
          //~ fprintf(stderr, "ERROR EN FTRUNCATE\n");
          //~ return 255;
    //~ }
	
	// Se mapea la memoria compartida al espacio de memoria del proceso
	ptr = mmap(NULL, 10, PROT_READ, MAP_SHARED, fd, 0 );
	if (ptr == (void *)-1){
          fprintf(stderr, "ERROR EN MMAP\n");
          return 255;
    }
    printf ("Direccion de memoria local donde arranca la memoria %p\n", ptr);	
    
    /* Determine the size of the shared memory*/
	if (fstat(fd, &sb) == -1)
	    	exit(-1);
	    	
 	// Se lee el estado de la memoria y se guarda en la estructura sb
	if(leido == -1){
		printf("Error al leer memoria. %s \n", strerror(errno)); 
	}
	else
	{
		printf("Leido %d", leido); 
	}
		
		
	printf("Buffer %s", buff); 
    //~ write (STDOUT_FILENO, buff, leido-1);
    
    return 0;
}
