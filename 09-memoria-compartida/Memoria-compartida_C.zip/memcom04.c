/*  
 * Ejercicio 4 de la guía práctica Memoria compartida
 * 
 */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/shm.h>

#define MEM_COM "MEM_COMPARTIDA_3"
#define MENSAJE "INFORMACION PARA OTRO PROCESO\n"

int main()
{	
	int fd, ft, leido, largo, i;
	int contador;
	int *ptr;
	char buff[1024];
	struct stat sb;
	
	// Se crea el objeto de memoria compartida
	fd = shm_open(MEM_COM , O_RDWR|O_CREAT, 0777 );
	if (fd == -1){
          fprintf(stderr, "ERROR EN OPEN\n");
          return 255;
        }
	
	// Se dimensiona la memoria y se pone a cero
	largo = 1024;	
	ft = ftruncate(fd, largo);
	if (ft == -1){
          fprintf(stderr, "ERROR EN FTRUNCATE\n");
          return 255;
    }
	
	// Se mapea la memoria compartida al espacio de memoria del proceso
	ptr = mmap(NULL, 10, PROT_READ, MAP_SHARED, fd, 0 );
	if (ptr == (void *)-1){
          fprintf(stderr, "ERROR EN MMAP\n");
          return 255;
    }
    //~ printf ("Direccion de memoria local donde arranca la memoria %p\n", ptr);	
    
    contador = 0x39; // Se inicializa en 9 ASCII
    for(i=0;i<10;i++)
    {
		// Se copia información en la memoria		
		write (fd, &contador, sizeof(contador));
		contador = contador+1;
		sleep(1);
	}
        	
 	leido = read(fd, buff, sizeof(contador));
 	if(leido == -1){
		printf("Error al leer memoria. %s \n", strerror(errno)); 
	}
	
	/* Determine the size of the shared memory*/
	if (fstat(fd, &sb) == -1)
	    	exit(-1);
	    	
 	// Se lee de la memoria compartida y se imprime por pantalla
	write(STDOUT_FILENO, ptr, sb.st_size);
    printf("\n");
    
    return 0;
}
