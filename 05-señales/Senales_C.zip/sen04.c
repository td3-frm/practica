/*
 * Ejercicio 4 de la guía práctica Señales
*/
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>

void manejador_kill(){
	
	printf ("No voy a terminar.\n");
	
	//~ exit(NULL);
}

int main (){

	signal(SIGKILL, manejador_kill);
    
    printf("Mi numero de PID es %d\n", getpid());
    
	while(1);
	
	return 0;
}
