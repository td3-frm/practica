/*
 * Ejercicio 3 de la guía práctica Señales
*/
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>

int main (){

	signal(SIGKILL, SIG_IGN);
    
    printf("Mi numero de PID es %d\n", getpid());	
    
	while(1);
	
	return 0;
}
