/*
 * Ejercicio 2 de la guia practica Procesos
*/
#include <stdio.h>
#include <sys/types.h>    // Define pid_t
#include <unistd.h>       // Define fork, getpid y getppid
#include <signal.h>

int main (){

	pid_t pid;
	
	pid = fork();
	printf ("Mi pid es %d y el pid de papa es %d. fork() devolvio %d\n", getpid(),getppid(),pid);
	sleep(30); // Probar con el comando pstree
	return 0;

}
