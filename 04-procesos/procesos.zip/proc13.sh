# 
# Ejercicio 13 de la guia practica Procesos
#

#!/bin/bash

ls -al  > ./stdout

cat stdout
