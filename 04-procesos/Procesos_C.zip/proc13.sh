# 
# Ejercicio 13 de la guía práctica Procesos
#

#!/bin/bash

ls -al  > ./stdout

cat stdout
